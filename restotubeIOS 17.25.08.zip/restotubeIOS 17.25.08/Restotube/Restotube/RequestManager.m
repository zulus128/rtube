//
//  RequestManager.m
//  Restotube
//
//  Created by Maksim Kis on 04.04.15.
//  Copyright (c) 2015 Maksim Kis. All rights reserved.
//

#import "RequestManager.h"

static NSString * const AppBaseUrlString = @"http://restotube.ru/api/";

@implementation RequestManager

+ (instancetype)sharedManager {
    static RequestManager *_sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedManager = [[RequestManager alloc] initWithBaseURL:[NSURL URLWithString:AppBaseUrlString]];
        _sharedManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    });
    
    return _sharedManager;
}

@end
