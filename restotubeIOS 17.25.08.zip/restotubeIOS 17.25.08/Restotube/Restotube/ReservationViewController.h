//
//  ReservationViewController.h
//  Restotube
//
//  Created by Andrey Rebrik on 13.04.15.
//  Copyright (c) 2015 Maksim Kis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Restaurants.h"

@interface ReservationViewController : UIViewController <UITextViewDelegate, UITextFieldDelegate, UIActionSheetDelegate>
{
    IBOutlet UIScrollView *mainScroll;
    IBOutlet UIView *fadView;
    
    IBOutlet UILabel *addressLabel;
    
    IBOutletCollection(UIView) NSArray *textfields;
    
    IBOutlet UITextField *dateTextField;
    IBOutlet UITextField *timeTextField;
    
    IBOutlet UITextField *nameField;
    IBOutlet UITextField *surnameField;
    IBOutlet UITextField *phoneField;
    IBOutlet UITextField *peopleField;
    IBOutlet UITextView *commentTextView;
    IBOutlet UIView *dateBackground;
    IBOutlet UIView *timeBackground;
    IBOutlet UIView *addressBackground;
    
    IBOutlet UILabel *dateLabel;
    IBOutlet UILabel *timeLabel;
    
    IBOutlet UIButton *doneButtonAcessoryView;
    
    __weak IBOutlet UIButton *resrveWithDiscountButton;
    IBOutlet UIButton *resrveButton;
}
@property (strong, nonatomic) UIView *fadeView;

@property (nonatomic, strong) Restaurants *restaurant;

- (IBAction)datePressed:(id)sender;
- (IBAction)timePressed:(id)sender;

- (IBAction)addressPressed:(id)sender;

- (IBAction)reserveWithDiscountPressed:(id)sender;
- (IBAction)reservePressed:(id)sender;

- (IBAction)doneButtonPreesed:(id)sender;

@end