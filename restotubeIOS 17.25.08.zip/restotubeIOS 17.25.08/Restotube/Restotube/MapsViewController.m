//
//  MapsViewController.m
//  Restotube
//
//  Created by Maksim Kis on 13.04.15.
//  Copyright (c) 2015 Maksim Kis. All rights reserved.
//

#import "MapsViewController.h"
#import "MapsInstance.h"
#import "UIAlertView+AFNetworking.h"
#import "UIMapsMarker.h"
#import "UIImage+MapsView.h"
#import "RestaurantsDetailViewController.h"
#import "QuartzCore/QuartzCore.h"

@interface MapsViewController ()
@property (strong,nonatomic) GMSMapView* googleMapsView;

@end



@implementation MapsViewController 
@synthesize activityIndicatorObject;

-(void) viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"head-line"] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setTranslucent:false];
    [self.navigationItem setTitleView:[[UIImageView alloc] initWithImage:[UIImage imageNamed: @"restotube-logo"]]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(locationUpdated:)
                                                 name:@"LocationUpdated"
                                               object:nil];
    GMSCameraPosition *camera = nil;
    
    if([[MapsInstance getInstance] myLocationLoaded] == YES) {
         camera = [GMSCameraPosition cameraWithTarget:[[MapsInstance getInstance] getMyLocation] zoom:13];
    }
    else {
        CLLocationCoordinate2D customLocation;
        customLocation.latitude = 55.755786000000001;
        customLocation.longitude = 37.617632999999998;
        camera = [GMSCameraPosition cameraWithTarget:customLocation zoom:13];
    }
   self.googleMapsView = [GMSMapView mapWithFrame:_containerView.bounds camera:camera];
    [self.googleMapsView clear];
    [self.googleMapsView setFrame:self.view.bounds];
   self.googleMapsView.myLocationEnabled = YES;
    self.googleMapsView.delegate = self;
    [self.view addSubview:self.googleMapsView];
    _googleMapsView.layer.zPosition = 1;
     [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    self.containerView.hidden = YES;
    
}

- (void)reloadData
{
    if(self.restaurants == nil) {
        activityIndicatorObject = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        activityIndicatorObject.alpha = 1.0;
        CGSize sizeOfScreen = [[UIScreen mainScreen] bounds].size;
        activityIndicatorObject.center = CGPointMake(sizeOfScreen.width / 2, sizeOfScreen.height / 2 - activityIndicatorObject.bounds.size.height);
        [self.view addSubview:activityIndicatorObject];
        [activityIndicatorObject  startAnimating];
        activityIndicatorObject.layer.zPosition = 2;
        [activityIndicatorObject setBackgroundColor:[UIColor blackColor]];
        NSURLSessionTask *task = [Restaurants restaurantsWithBlock:0: 0: 0: 0: ^(NSArray *categories, NSError *error) {
            if (!error) {
                self.restaurants = categories;
                
                for(int i = 0 ; i < [self.restaurants count] ; i ++ ) {
                    Restaurants* restaurant = [self.restaurants objectAtIndex:i];
                    NSString* name =  restaurant.name;
                    
                    for(int j = 0; j < [restaurant.addresses count]; j++) {
                        Addresses* address = [restaurant.addresses objectAtIndex:j];
                        
                        CLLocationCoordinate2D coordinate;
                        coordinate.latitude =  [address.lat floatValue];
                        coordinate.longitude = [address.lon floatValue];
                        UIMapsMarker *marker = [[UIMapsMarker alloc] init];
                        [marker setId:i];
                        [marker setIcon:[UIImage restaurantTitleImageWithTitle:name]];
                        [marker setPosition:coordinate];
                        [marker setMap:_googleMapsView];
                    }
                }
            }
            [activityIndicatorObject  stopAnimating];
            [[UIApplication sharedApplication] endIgnoringInteractionEvents];
        }];
        
        [UIAlertView showAlertViewForTaskWithErrorOnCompletion:task delegate:nil];
    }
    
    else {
        
        
        
        for(int i = 0 ; i < [self.restaurants count] ; i ++ ) {
            Restaurants* restaurant = [self.restaurants objectAtIndex:i];
            NSString* name =  restaurant.name;
            
            for(int j = 0; j < [restaurant.addresses count]; j++) {
                Addresses* address = [restaurant.addresses objectAtIndex:j];
                
                CLLocationCoordinate2D coordinate;
                coordinate.latitude =  [address.lat floatValue];
                coordinate.longitude = [address.lon floatValue];
                UIMapsMarker *marker = [[UIMapsMarker alloc] init];
                [marker setId:i];
                [marker setIcon:[UIImage restaurantTitleImageWithTitle:name]];
                [marker setPosition:coordinate];
                [marker setMap:_googleMapsView];
              
            }
        }
        
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [self reloadData];
}

- (void) dealloc
{
    // If you don't remove yourself as an observer, the Notification Center
    // will continue to try and send notification objects to the deallocated
    // object.
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    if (self.googleMapsView != nil ) {
        [self.googleMapsView removeFromSuperview];
    }

}


- (void) locationUpdated:(NSNotification *) notification  {
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithTarget:[[MapsInstance getInstance] getMyLocation]  zoom:13];
    _googleMapsView = [GMSMapView  mapWithFrame:CGRectZero camera:camera];
    _googleMapsView.myLocationEnabled = YES;
    _googleMapsView.delegate = self;

    NSLog(@"!!%f -- %f",    _googleMapsView.myLocation.coordinate.latitude,     _googleMapsView.myLocation.coordinate.longitude);
}


- (BOOL) mapView:(GMSMapView *)mapView didTapMarker:(GMSMarker *)marker
{
    int idx = [(UIMapsMarker *)marker Id];
    
    Restaurants *category = [self.restaurants objectAtIndex:(NSUInteger)idx];
    [self performSegueWithIdentifier:@"restaurantsDetailSegue" sender:category];
    return YES;
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"restaurantsDetailSegue"])
    {
        RestaurantsDetailViewController *controller = (RestaurantsDetailViewController *)segue.destinationViewController;
        controller.restaurants = (Restaurants *)sender;
    }
}

@end
