//
//  RWLabel.h
//  Restotube
//
//  Created by Andrey Rebrik on 18.04.15.
//  Copyright (c) 2015 Maksim Kis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWLabel : UILabel

@end
