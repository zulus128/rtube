//
//  ReservationViewController.m
//  Restotube
//
//  Created by Andrey Rebrik on 13.04.15.
//  Copyright (c) 2015 Maksim Kis. All rights reserved.
//

#import "ReservationViewController.h"
#import "ReservationInfoViewController.h"
#import "Reservation.h"
#import "IAPHelper.h"

@implementation ReservationViewController
{
    NSString *timeString;
    NSString *dateString;
    NSDate *datePickerDate;
    NSDate *datePickerTime;
    Addresses *selectedAddress;
    
    Reservation *sendedReservation;
    IAPHelper *_helper;
}

- (void) viewDidLoad
{
    [super viewDidLoad];
    _helper = [IAPHelper helper];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onBuyed) name:@"IAPHelperProductPurchasedNotification" object:nil];
    
    [self.navigationItem setTitleView:[[UIImageView alloc] initWithImage:[UIImage imageNamed: @"restotube-logo"]]];
    
    for (UIView *field in textfields)
    {
        [field.layer setBorderColor:[[UIColor colorWithRed:167.0/255.0 green:169.0/255.0 blue:172.0/255.0 alpha:1.0] CGColor]];
        field.layer.borderWidth = 1.0f;
        
        if ([field isKindOfClass:[UITextField class]])
            field.layer.sublayerTransform = CATransform3DMakeTranslation(5, 0, 0);
    }
    
    timeString = @"";
    dateString = @"";
    
    if (_restaurant.addresses.count > 0)
    {
        selectedAddress = _restaurant.addresses[0];
        addressLabel.text = selectedAddress.name;
    }
    
    if([_restaurant.sale isEqualToString: @""]) {
        [resrveWithDiscountButton setHidden:YES];
    }
    else {
        NSString* str = [NSString stringWithFormat:@"Забронировать со скидкой %ld%%", (long)_restaurant.saleint];
        [resrveWithDiscountButton setTitle:str forState:UIControlStateNormal];
        [resrveWithDiscountButton setTitle:str forState:UIControlStateHighlighted];
        [resrveWithDiscountButton setTitle:str forState:UIControlStateSelected];
        [resrveWithDiscountButton setTitle:str forState:UIControlStateDisabled];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    mainScroll.contentSize = CGSizeMake(mainScroll.frame.size.width, resrveButton.frame.size.height + resrveButton.frame.origin.y + 37);
    [mainScroll setContentOffset:CGPointZero animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void) keyboardWillShow:(NSNotification *)notification
{
    CGFloat keyboardHeight = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    
    mainScroll.contentSize = CGSizeMake(mainScroll.frame.size.width, resrveButton.frame.size.height + resrveButton.frame.origin.y + 33 + keyboardHeight);
    
    UIView *view = [self findFirstResponder];
    if (view)
    {
        CGFloat offsetHeight = view.frame.size.height + view.frame.origin.y - (mainScroll.frame.size.height - keyboardHeight);
        offsetHeight = offsetHeight < 0 ? 0 : offsetHeight;
        [mainScroll setContentOffset:CGPointMake(0, offsetHeight) animated:YES];
    }
}

- (void) keyboardWillHide:(NSNotification *)notification
{
    mainScroll.contentSize = CGSizeMake(mainScroll.frame.size.width, resrveButton.frame.size.height + resrveButton.frame.origin.y + 37);
}

- (id)findFirstResponder
{
    for (UIView *subView in self.view.subviews)
        if ([subView isFirstResponder])
            return subView;
    
    return nil;
}

- (BOOL)isDataOk
{
    BOOL isDataOk = dateString && ![dateString isEqualToString:@""] &&
    timeString && ![timeLabel.text isEqualToString:@""] &&
    ![nameField.text isEqualToString:@""] &&
    ![surnameField.text isEqualToString:@""] &&
    [self strippedPhone].length == 10 &&
    ![peopleField.text isEqualToString:@""];
    
    for (UIView *field in textfields)
    {
        [field.layer setBorderColor:[[UIColor colorWithRed:167.0/255.0 green:169.0/255.0 blue:172.0/255.0 alpha:1.0] CGColor]];
        field.layer.borderWidth = 1.0f;
    }
    
    if (!dateString || [dateString isEqualToString:@""])
        [dateBackground.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
    if (!timeString || [timeString isEqualToString:@""])
        [timeBackground.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
    if ([nameField.text isEqualToString:@""])
        [nameField.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
    if ([surnameField.text isEqualToString:@""])
        [surnameField.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
    if ([self strippedPhone].length < 10)
        [phoneField.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
    if ([peopleField.text isEqualToString:@""])
        [peopleField.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
    
    NSString *alertMessage = @"Пожалуйста Заполните все обязательные поля.";
    
    if (datePickerDate && datePickerTime)
    {
        if (([datePickerDate compare: [NSDate date]] != NSOrderedDescending) &&
            ([datePickerTime compare: [NSDate date]] != NSOrderedDescending))
        {
            [timeBackground.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
            [dateBackground.layer setBorderColor:[[UIColor colorWithRed:255.0/255.0 green:37.0/255.0 blue:103.0/255.0 alpha:1.0] CGColor]];
            isDataOk = NO;
            alertMessage = @"Некорректно указаны дата и время.";
        }
    }
    
    if (!isDataOk)
        [[[UIAlertView alloc] initWithTitle:@"Внимание!" message:alertMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
    
    return isDataOk;
}


#pragma mark - Actions


- (void)addressPressed:(id)sender
{
    UIView *responder = [self findFirstResponder];
    if (responder) [responder resignFirstResponder];
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Адрес"
                                                             delegate:self
                                                    cancelButtonTitle:nil
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:nil];
    
    for (Addresses *address in _restaurant.addresses)
        [actionSheet addButtonWithTitle:address.name];
    
    actionSheet.cancelButtonIndex = [actionSheet addButtonWithTitle:@"Отмена"];
    
    [actionSheet showInView:self.view];
}

- (void)datePressed:(id)sender
{
    [dateTextField becomeFirstResponder];
}

- (void)timePressed:(id)sender
{
    [timeTextField becomeFirstResponder];
}

- (void)reserveWithDiscountPressed:(id)sender
{
    if (![self isDataOk]) return;
    
    [self.view endEditing:YES];
    ((UIButton *)sender).enabled = NO;

    NSDictionary *params = @{@"date" : dateString,
                             @"time" : timeString,
                             @"col" : peopleField.text,
                             @"surname" : surnameField.text,
                             @"name" : nameField.text,
                             @"phone" : [self strippedPhone],
                             @"address" : selectedAddress.address_Id,
                             @"text" : commentTextView.text,
                             @"buy_sale" : @1};
    
    [self.view addSubview:self.fadeView];
    [Reservation sendReserveRequest:params
                     WithCompletion:^(Reservation *reservation, NSError *error)
    {
          sendedReservation = reservation;
        
        [_helper requestProductsWithCompletionHandler:^(BOOL success, NSArray *products) {
            NSString *identifier = [NSString stringWithFormat:@"ru.restotube.InAppPurchases.reservation%d",_restaurant.saleint];
            BOOL exist = false;
            for (SKProduct *product in products)
            {
                if ([product.productIdentifier isEqualToString:identifier])
                {
                    exist = YES;
                    [_helper buyProduct:product];
                    break;
                }
            }
            
            if (!exist)
            {
                [self.fadeView removeFromSuperview];
                ((UIButton *)sender).enabled = YES;
                if (reservation.sale_url && ![reservation.sale_url isEqualToString:@""])
                {
                    NSURL *url;
                    
                    if ([reservation.sale_url rangeOfString:@"http"].location == NSNotFound)
                        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@", reservation.sale_url]];
                    else
                        url = [NSURL URLWithString:reservation.sale_url];
                    
                    [[UIApplication sharedApplication]  openURL:url];
                }
            }
        }];
        
    }];
}

- (void)onBuyed
{
    if (sendedReservation != nil)
    {
        NSDictionary *params = @{@"id" : sendedReservation.reservation_id,
                                 @"hash" : sendedReservation.reservation_hash};
        
        [Reservation sendReservedRequest:params WithCompletion:^(NSDictionary *response, NSError *error) {
            [self performSegueWithIdentifier:@"ReservationResponseSegue" sender:nil];
        }];
        [self.fadeView removeFromSuperview];
    }
}

- (void)reservePressed:(id)sender
{
    if (![self isDataOk]) return;
    
    NSDictionary *params = @{@"date" : dateString,
                             @"time" : timeString,
                             @"col" : peopleField.text,
                             @"surname" : surnameField.text,
                             @"name" : nameField.text,
                             @"phone" : [self strippedPhone],
                             @"address" : selectedAddress.address_Id,
                             @"text" : commentTextView.text};
    
    [Reservation sendReserveRequest:params
                     WithCompletion:^(Reservation *reservation, NSError *error) {
                         sendedReservation = reservation;
                         [self performSegueWithIdentifier:@"ReservationResponseSegue" sender:nil];
                     }];
}

- (NSString *)strippedPhone
{
    if (![phoneField.text isEqualToString:@""])
    {
        NSString *string = [phoneField.text substringFromIndex:3];
        string = [string stringByReplacingOccurrencesOfString:@") " withString:@""];
        
        return string;
    }
    
    return @"";
}


#pragma mark - UIActionSheetDelegate


- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex < _restaurant.addresses.count)
    {
        selectedAddress = _restaurant.addresses[buttonIndex];
        addressLabel.text = selectedAddress.name;
    }
}


#pragma mark - UITextFieldDelegate


- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == dateTextField)
    {
        if (!datePickerDate)
            datePickerDate = [NSDate date];
        
        UIDatePicker *datePicker = [[UIDatePicker alloc]init];
        [datePicker setMinimumDate:[NSDate date]];
        datePicker.backgroundColor = [UIColor whiteColor];
        [datePicker setDate:datePickerDate];
        [datePicker setDatePickerMode:UIDatePickerModeDate];
        [datePicker addTarget:self action:@selector(updateTextField:) forControlEvents:UIControlEventValueChanged];
        [textField setInputView:datePicker];
        [textField setInputAccessoryView:doneButtonAcessoryView];
        
        [self updateTextField:nil];
        fadView.hidden = NO;
    }
    else if (textField == timeTextField)
    {
        if (!datePickerTime)
            datePickerTime = [self getRoundedMinimumDate:[NSDate date]];
        
        UIDatePicker *datePicker = [[UIDatePicker alloc] init];
        
        if (!datePickerDate || ([datePickerDate compare: [NSDate date]] != NSOrderedDescending))
            [datePicker setMinimumDate:[self getRoundedMinimumDate:[NSDate date]]];
        
        [datePicker setDate:datePickerTime];
        [datePicker setDatePickerMode:UIDatePickerModeTime];
        [datePicker setMinuteInterval:10];
        datePicker.backgroundColor = [UIColor whiteColor];
        [datePicker addTarget:self action:@selector(updateTextField:) forControlEvents:UIControlEventValueChanged];
        [textField setInputView:datePicker];
        [textField setInputAccessoryView:doneButtonAcessoryView];
        
        [self updateTextField:nil];
        fadView.hidden = NO;
    }
    else if (textField == phoneField)
    {
        if (textField.text.length == 0 || [textField.text isEqualToString:@"+7("])
        {
            textField.text = @"+7(";
        }
    }
}

- (void)updateTextField:(id)sender
{
    if ([dateTextField isFirstResponder])
    {
        UIDatePicker *picker = (UIDatePicker*)dateTextField.inputView;
        datePickerDate = picker.date;
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"dd MMMM, EE"];
        dateLabel.text = [formatter stringFromDate:picker.date];
        
        NSDateFormatter *sendformatter = [[NSDateFormatter alloc] init];
        [sendformatter setDateFormat:@"yyyy-MM-dd"];
        dateString = [sendformatter stringFromDate:picker.date];
    }
    else if ([timeTextField isFirstResponder])
    {
        UIDatePicker *picker = (UIDatePicker*)timeTextField.inputView;
        
        datePickerTime = picker.date;
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"HH:mm"];
        timeLabel.text = [formatter stringFromDate:picker.date];
        
        NSDateFormatter *sendformatter = [[NSDateFormatter alloc] init];
        [sendformatter setDateFormat:@"HH:mm"];
        timeString = [formatter stringFromDate:picker.date];
    }
}

- (NSDate *)getRoundedMinimumDate:(NSDate *)inDate{
    
    NSDate *returnDate;
    NSInteger minuteInterval = 10;
    NSDateComponents *dateComponents = [[NSCalendar currentCalendar] components:NSMinuteCalendarUnit | NSHourCalendarUnit fromDate:inDate];
    NSInteger minutes = [dateComponents minute];
    
    NSInteger minutesToRound = minuteInterval - (NSInteger)(minutes % minuteInterval);
    
    NSDate *roundedDate = [[NSDate alloc] initWithTimeInterval:60.0 * minutesToRound  sinceDate:inDate];
    
    returnDate = roundedDate;
    return returnDate;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    fadView.hidden = YES;
    
    [textField resignFirstResponder];
    
    if (textField == dateTextField)
        [timeTextField becomeFirstResponder];
    else if (textField == timeTextField)
        [peopleField becomeFirstResponder];
    else if (textField == peopleField)
        [nameField becomeFirstResponder];
    else if (textField == nameField)
        [surnameField becomeFirstResponder];
    else if (textField == surnameField)
        [phoneField becomeFirstResponder];
    else if (textField == phoneField)
        [commentTextView becomeFirstResponder];
    
    return YES;
}

- (void)doneButtonPreesed:(id)sender
{
    fadView.hidden = YES;
    
    if ([dateTextField isFirstResponder])
        [self textFieldShouldReturn:dateTextField];
    else if ([timeTextField isFirstResponder])
        [self textFieldShouldReturn:timeTextField];
    else if ([commentTextView isFirstResponder])
        [commentTextView resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == phoneField || textField == peopleField)
    {
        if ([string rangeOfCharacterFromSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]].location != NSNotFound)
        {
            return NO;
        }
        
        if (textField == phoneField)
        {
            if (string.length > 1 || range.length > 1)
                return NO;
            if (range.length <= 3 && range.location == 0)
                return NO;
            
            if (textField.text.length <= 3)
            {
                textField.text = [NSString stringWithFormat:@"%@%@", @"+7(", string];
                return NO;
            }
            
            if (range.location == 15 || textField.text.length > 15)
                return NO;
            
            if (range.location == 6)
            {
                textField.text = [textField.text stringByAppendingString:@") "];
                return YES;
            }
            if (range.location == 7)
            {
                textField.text = [textField.text substringToIndex:5];
                return YES;
            }
        }
    }
    
    if (textField == peopleField)
    {
        NSString * proposedNewString = [[textField text] stringByReplacingCharactersInRange:range withString:string];
        
        if (proposedNewString.intValue > 15)
        {
            textField.text = @"15";
            return NO;
        }
    }
    
    return YES;
}


#pragma mark - UITextViewDelegate


- (void)textViewDidBeginEditing:(UITextView *)textView
{
     [textView setInputAccessoryView:doneButtonAcessoryView];
}


#pragma mark - Navigation


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"ReservationResponseSegue"])
    {
        ReservationInfoViewController *controller = (ReservationInfoViewController *)segue.destinationViewController;
        controller.reservation = sendedReservation;
        controller.nameString = [NSString stringWithFormat:@"%@ %@", nameField.text, surnameField.text];
    }
}

- (UIView *)fadeView
{
    if (_fadeView == nil)
    {
        _fadeView = [[UIView alloc] initWithFrame:self.view.bounds];
        _fadeView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        UIActivityIndicatorView *activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        [activity sizeToFit];
        activity.center = _fadeView.center;
        activity.backgroundColor = [UIColor clearColor];
        activity.color = [UIColor colorWithRed:204/255.0 green:50/255.0 blue:101/255.0 alpha:1];
        [activity startAnimating];
        [_fadeView addSubview:activity];
    }
    return _fadeView;
}

@end