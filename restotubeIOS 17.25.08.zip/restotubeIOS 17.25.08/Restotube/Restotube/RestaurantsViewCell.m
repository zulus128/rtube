//
//  RestaurantsViewCell.m
//  Restotube
//
//  Created by Maksim Kis on 08.04.15.
//  Copyright (c) 2015 Maksim Kis. All rights reserved.
//

#import "RestaurantsViewCell.h"
#import "UIImageView+AFNetworking.h"
#import "MapsInstance.h"

@implementation RestaurantsViewCell

- (void) dealloc
{
    // If you don't remove yourself as an observer, the Notification Center
    // will continue to try and send notification objects to the deallocated
    // object.
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
//    [super dealloc];
}


- (void) awakeFromNib {
    
    _imageDiscount.layer.masksToBounds = YES;
    _imageDiscount.layer.cornerRadius = _imageDiscount.frame.size.height/2;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(locationUpdatedNotification:)
                                                 name:@"LocationUpdated"
                                               object:nil];
}


- (void) locationUpdatedNotification:(NSNotification *) notification {
    NSArray* addresses = self.restaurantInfo.addresses;
    if([addresses count]) {
        Addresses* address = [addresses objectAtIndex:0];
        CLLocationCoordinate2D _mylocation = [[MapsInstance getInstance] getMyLocation];
        CLLocationCoordinate2D coordinate;
        coordinate.latitude = [address.lat doubleValue];
        coordinate.longitude =  [address.lon doubleValue];
        CLLocationDistance distance =  GMSGeometryDistance(_mylocation, coordinate);
        distance = distance / 1000;
        NSNumberFormatter *fmt = [[NSNumberFormatter alloc] init];
        [fmt setPositiveFormat:@"0.#"];
        NSString* format = [ NSString stringWithFormat:@"%@ км", [fmt stringFromNumber:[NSNumber numberWithFloat:distance]]];
        self.labelDistance.text = format;
    }
    else {
        self.labelDistance.text = @"";
    }
}


- (void) setRestaurant:(Restaurants *)restaurant {
    self.restaurantInfo = restaurant;
    self.labelName.text = restaurant.name;
    self.labelLikes.text = [NSString stringWithFormat:@"%ld", (long)restaurant.likes];
    self.labelTime.text = restaurant.work_time;
    
    if([restaurant.sale isEqualToString:@""] == false) {
        self.labelDiscount.text = restaurant.sale;
    }
    else {
        self.labelDiscount.hidden = true;
        self.imageDiscount.hidden = true;
    }
    

    
    NSURLRequest* req_bg = [NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://restotube.ru%@", restaurant.img]]];

    __weak UIImageView *weakImageView = self.imageViewBackground;

    [self.imageViewBackground setImageWithURLRequest:req_bg placeholderImage:nil success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
        UIImageView *strongImageView = weakImageView;
        if (!strongImageView) return;
        
        [UIView transitionWithView:strongImageView
                          duration:0.3
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            strongImageView.image = image;
                        }
                        completion:NULL];
    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
        
    }];
    
    
    [self setNeedsLayout];
}

@end
